//import UIKit
//
//var greeting = "Hello, playground"
import Foundation
 //creating variables

let firstName: Array<String> = ["Daniel", "Mark", "Sam", "Pierre", "Jean"]
let lastName: Array<String> = ["Carvalho", "Zukemberg", "Smith", "Olivier", "Francois"]
let height: Array<Int> = [174, 178, 166, 182, 177] // in centimeters
let weight: Array<Double> = [82.5, 78.2, 120.0, 71.2, 92.9] // in kg
var p_num:Int=0
var bmi_class:String=""
// Use nested zip functions to combine the arrays
for ((first, last), (h, w)) in zip(zip(firstName, lastName), zip(height, weight)) {
   
    //print("Name: \(first) \(last), Height: \(h) cm, Weight: \(w) kg")
    p_num+=1
    print("Patient number ",p_num," : ",first+" "+last )
    print("Height : ",h,"cm")
    print("Weight : ",w,"Kg")
    let bmi = ((w*100*100)/Double(h*h)).rounded()
   
    
   // print("BMI : ","{:.2f}.format(bmi)")
    print("BMI : ",bmi)
    if bmi<18.5{
       bmi_class=" underweight"
    }
    else if bmi>=18.5 && bmi<=24.9{
         bmi_class=" normal weight"
    }
    else if bmi>=25.0 && bmi<=29.9{
         bmi_class=" overweight"
    }
    else{
         bmi_class=" obesity"
    }
    print("Classification : ",bmi_class)
    print("\n")
    
    
    
    
}


            
